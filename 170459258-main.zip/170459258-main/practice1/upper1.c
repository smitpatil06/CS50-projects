#include <stdio.h>
#include <ctype.h>

void cap(char str[])
{
    int i = 0;
    while (str[i] != '\0')
    {
        if (i == 0 || str[i - 1] == ' ')
        {
            str[i] = toupper(str[i]);
        }
        i++;
    }
}

int main()
{
    char str[100];
    printf("Enter the string: ");
    fgets(str, sizeof(str), stdin);
    cap(str);
    printf("String: %s", str);
    return 0;
}
