#include<stdio.h>

int main()
{
int i=0, a=1;
    for(i=0;i<2;i++)
    {

        while(i<10)
        {
        printf(" ");
        i++;
        }
        while(i<a)
        {
            printf("*");
            i++;
        }
        a+=2;
printf("\n");
    }
}
