#include<ctype.h>
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int main()
{
    char *s=malloc(100* sizeof(char));
    fgets(s,100,stdin);
    s[0]=toupper(s[0]);

     for(int i = 0;s[i] != '\0';i++)
    {
        if (i == 0 || s[i - 1] == ' ')
        {
            s[i] = toupper(s[i]);
        }
        if(s[i]=='\0')
        {
            break;
        }
    }


     printf("%s\n",s);
free(s);
    return 0;
}
