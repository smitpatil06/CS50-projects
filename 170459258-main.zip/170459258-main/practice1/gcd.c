#include<stdio.h>

int main()
{
    int gcd = 0, lcm = 0, i, num1, num2;
    printf("Enter the numbers: ");
    scanf("%d %d", &num1, &num2);

    // Calculate GCD
    for (i = 1; i <= num1 && i <= num2; i++) {
        if (num1 % i == 0 && num2 % i == 0) {
            gcd = i;
        }
    }

    // Calculate LCM
    lcm = (num1 * num2) / gcd;

    printf("GCD: %d\nLCM: %d\n", gcd, lcm);

    return 0;
}
