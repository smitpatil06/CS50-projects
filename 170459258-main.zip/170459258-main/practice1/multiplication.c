#include <stdio.h>
int table(int a);
int main()
{
    int a;
    // Enther the no. whose table u want
    scanf("%d",&a);

    table(a);
    return 0;
}

int table(int a)
{int b=1;
    for(int i=1;i<=10;i++)
    {
        b = a*i;
        printf("%d\n",b);
    }
return 0;
}
