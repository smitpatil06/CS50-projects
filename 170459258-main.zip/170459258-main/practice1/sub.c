#include<stdio.h>
int main()
{
    int a[5],b[5];
a[0]=0;
b[0]=0;
for(int i =1;i<=5;i++)
{
scanf("%d",&a[i]);
printf("out of");
scanf("%d",&b[i]);
}

      for(int i =1;i<=5;i++)
    {
        a[0] +=a[i];
        b[0] +=b[i];
    }
    printf("%f",(float)(a[0]/b[0])*100 );
}
