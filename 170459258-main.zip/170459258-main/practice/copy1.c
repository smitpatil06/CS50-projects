#include <cs50.h>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
    char *a;
    scanf("%s", a);

    int n = strlen(a);
    char *j = malloc(n + 1);

    strcpy(j, a);

    j[0] = toupper(j[0]);

    printf("%s\n", a);
    printf("%s\n", j);

    free(j);
    return 0;
}
