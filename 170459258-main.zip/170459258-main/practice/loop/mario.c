#include <stdio.h>

int main(void)
{
    for( int m= 0; m < 5; m++)
    {
        for( int i= 0; i < 5; i++)
        {
            printf("#");

        }
        printf("\n");
   }
}
