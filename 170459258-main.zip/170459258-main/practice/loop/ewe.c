#include <stdio.h>
#include <cs50.h>

int main(void)
{
    int n = get_int("how many would you like this to repeat: ");
    int i = 0;
    while(i < n)
    {
        printf("ewe\n");
        n++;
    }
}
