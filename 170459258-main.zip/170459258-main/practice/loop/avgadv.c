#include<stdio.h>
#include<cs50.h>

int main(void)
{
    int N;
    scanf("%d",&N);
   int a[N];
    int sum=0;
    for(int i=0;i<N;i++)
    {
    
    scanf("%d",&a[i]);
    // sum = sum + i
    sum +=a[i];
    }
// casting = (float)
    printf("avg= %f\n",sum/ (float)N);

}
