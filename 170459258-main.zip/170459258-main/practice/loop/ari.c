#include <stdio.h>
#include <cs50.h>

int main(void)
{
    int n = get_int("reapeat: ");
    for (int i = 0; i <= n; i++)
    {
        printf("ari ");
    }
}
