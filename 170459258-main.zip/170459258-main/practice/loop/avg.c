#include<stdio.h>
#include<cs50.h>

int main(void)
{
   const int N=3;
   int a[N];
   for(int i=0;i<N;i++)
    {
        a[i]=get_int("a=");
    }

    printf("avg= %f\n",(a[0] + a[1] + a[2])/(float) N);

}
