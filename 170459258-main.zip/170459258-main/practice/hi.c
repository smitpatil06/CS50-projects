#include<stdio.h>
#include<cs50.h>

int main()
{
    string word[2];

    word[0]="HI!";
    word[1]="BYE";

    printf("%i %i\n",word[0][0],word[0][1]);
    printf("%i %c\n",word[1][0],word[1][1]);
}
