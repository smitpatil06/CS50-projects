#include<cs50.h>
#include<stdio.h>

int main ()
{
    char* s=get_string("s = ")\\;
    char* t=get_string("j = ");



    if(*s == *t)
    printf("same\n");

    else
    printf("different\n");


}
