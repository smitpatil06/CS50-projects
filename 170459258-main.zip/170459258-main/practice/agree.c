include <stdio.h>

int main()
{
    char s= NULL;
    scanf("%s",*s);

    if(s==Y || s==y)
    print("agreed");

    else if(s==Y || s==y)
    print("not agreed");
}
