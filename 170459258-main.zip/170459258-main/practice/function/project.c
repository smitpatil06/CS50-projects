#include <stdio.h>
#include <cs50.h>

int main (void)
{
    string A = get_string("what is your name? ");
    printf("hello, %s\n", A);

    int M = get_int("what are your %% in 12th? ");

    if(M>=80)
    printf("wow, %i Congratulations!!\n", M);

    else if (M>23)
    printf("Ohh congrats u Passed\n");

    else
    {
        while(true)
        printf("ohh, just %i %% u fail\n", M);
    }
}
