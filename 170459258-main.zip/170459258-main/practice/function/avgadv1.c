#include<stdio.h>
#include<cs50.h>

// prototype
float avg(int l,int array[]);

int main(void)
{
    int N=get_int("N= ");
    int a[N];
    for(int i = 0;i<N;i++)
    {
        a[i]=get_int("a= ");
    }

// casting = (float)
    printf("avg= %f\n",avg(N,a));

}


float avg(int l,int array[])
{
// cal avg
    int sum=0;
    for(int i=0;i<l;i++)
    {
        sum +=array[i];
    }
        return sum / (float) l;
}
