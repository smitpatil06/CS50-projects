#include <stdio.h>
#include <cs50.h>

void height(int a);

int main(void)
{
    int h =get_int("height:");
    height(h);

}


void height(int a)
{
    for(int i=0; i<=a; i++)
    {
        printf("#\n");
    }

}
