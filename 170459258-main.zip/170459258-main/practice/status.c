#include<cs50.h>
#include<stdio.h>

int main(int m,string n[])
{


     if (m !=2)
{
        printf("missing command line argument\n");
return 1;
}
        printf("hello, %s\n",n[1]);
return 0;
}
