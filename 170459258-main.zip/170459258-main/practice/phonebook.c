#include <stdio.h>
#include <cs50.h>
#include <stdlib.h>

int main()
{
   FILE *file =fopen("phonebook.csv","w");
    char *name= malloc(5*sizeof(char));
    char *num= malloc(5*sizeof(char));
    scanf("%s",name);
    scanf("%s",num);

    fprintf(file,"%s,%s\n",name,num);
    fclose(file);
}

