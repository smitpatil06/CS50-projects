#include<stdio.h>

int main ()
{
    char s[50];// this can be solved by using malloc or using s[<number>]c
    printf("s:");
    scanf("%s",s);
    printf("s: %s",s);

}
