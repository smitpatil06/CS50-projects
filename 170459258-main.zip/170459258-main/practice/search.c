#include <stdio.h>
#include <cs50.h>
#include <string.h>

int main ()
{
    string no[] = {"metal" , "piece", "blank" , "pure" };
    string n = get_string("string = ");

    for(int i=0;i<4;i++)
    {
        if(strcmp(no[i],n)== 0)
        {
        printf("found\n");
        return 0 ;
        }
    }
        printf("not found\n");
        return 1;
}
