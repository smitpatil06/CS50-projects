#include<cs50.h>
#include<ctype.h>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int main()
{
    char* s = get_string("s="); // this get string is modified scanf
if(s==NULL)
        {
            return 1;
        }
int n = strlen(s);

    char* j = malloc(n+1);
        if(j==NULL)
        {
            return 1;
        }
strcpy(j,s);

    j[0]= toupper(j[0]);

    printf("%s\n",s);
    printf("%s\n",j);

    free(j);
    return 1;
}
