#include<cs50.h>
#include<stdio.h>

int main(void)
{
    int x = get_int("x: ");
    int y = get_int("y: ");
// type castiong is used to avoid truncation
    float z = (float) x / (float) y ;
 printf("sum = %.20f\n", z );

}
