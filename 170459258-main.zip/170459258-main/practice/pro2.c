#include<stdio.h>
#include<cs50.h>

void dog(int n);

int main(void)
{
    int A = get_int("how many times will he bark?");
    dog(A);
}

void dog(int n)
{
    for (int B = 0; B < n; B++)
    printf("woof\n");
}
