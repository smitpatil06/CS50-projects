#include<stdio.h>
#include<cs50.h>

int main(void)
{
    int c;
    int r;
    // prompt user for pasitive integer in colunm
    do
    {
        c =get_int("colunm: ");
    }
    while( c < 1);
    // prompt user for pasitive integer in row
    do
    {
       r =get_int("row: ");
    }
    while( r < 1);

    for(int b = 0; b < r; b++)
    {
           for(int a = 0; a < c; a++)
           {
                 printf("?");
           }
           printf("\n");
    }
}
