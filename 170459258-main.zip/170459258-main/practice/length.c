#include<cs50.h>
#include<stdio.h>
#include<string.h>
int main()
{
    string name = get_string("name= ");
    int length =strlen(name);
    printf("%d\n",length);
}

