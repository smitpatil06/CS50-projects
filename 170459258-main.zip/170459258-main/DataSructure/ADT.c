#include <stdio.h>

#define MAX_SIZE 100

void insertElement(int arr[], int *n, int element, int position) {
    if (*n >= MAX_SIZE) {
        printf("Array is full. Cannot insert element.\n");
        return;
    }
    if (position < 0 || position > *n) {
        printf("Invalid position. Please enter a position between 0 and %d.\n", *n);
        return;
    }
    for (int i = *n; i > position; i--) {
        arr[i] = arr[i - 1];
    }
    arr[position] = element;
    (*n)++;
}

void printArray(int arr[], int n) {
    for (int i = 0; i < n; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");
}

int main() {
    int arr[MAX_SIZE] = {1, 2, 3, 4, 5};
    int n = 5;
    int element = 10;
    int position = 2;

    printf("Array before insertion: ");
    printArray(arr, n);

    insertElement(arr, &n, element, position);

    printf("Array after insertion: ");
    printArray(arr, n);

    return 0;
}
