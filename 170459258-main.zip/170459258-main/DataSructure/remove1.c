#include <stdio.h>

int removeDuplicates(int arr[], int n) {
    int j = 0;
    for(int i = 0; i < n - 1; i++) {
        if(arr[i] != arr[i + 1]) {
            arr[j++] = arr[i];
        }
    }
    arr[j++] = arr[n - 1];
    return j; 
}

int main() {
    int arr[] = {1, 2, 2, 3, 4};
    int n = 5;

    int newSize = removeDuplicates(arr, n);

    printf("Array after removing duplicates: ");
    for(int i = 0; i < newSize; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");

    return 0;
}
