#include <stdio.h>
int removeDuplicates(int arr[], int n) {
 int j = 0;
 for(int i = 0; i < n - 1; i++) {
 if(arr[i] != arr[i + 1]) {
 arr[j++] = arr[i];
 }
 }
 arr[j++] = arr[n - 1];
 return j; // New size of array
}
int main()
{
    int arr[] = {1,2,2,3,4}
    int n = 5

    int new removeDuplicates(arr,n)
}
