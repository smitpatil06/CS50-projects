#include <stdio.h>
#include <stdlib.h>
#include <cs50.h>

typedef struct node
{
    int no;
    struct node *next;
} node;

int main(void)
{
   node *list = NULL;
    for(int i = 0 ;i<3;i++)
    {
        node *x = malloc(sizeof(node));
         if(x==NULL)
            {
                 return 1;
            }
    x->no = get_int("No;");
    x->next = list;

    list = x;
            printf("%d\n",x->no);
    }

    node *ptr= list;
    while(ptr != NULL)
    {
        printf("%i\n", ptr->no);
        ptr = ptr->next;
    }
}
