#include <stdio.h>
#include <stdlib.h>

int main()
{
    int* x= malloc(3*sizeof(int));
    if(x == NULL)
    {
        return 1;
    }
    x[0] = 72;
    x[1] = 73;
    x[2] = 33;

    int *tmp= realloc(x,4*sizeof(int));
    if (tmp==NULL)
    {
        free(x);
        return 1;
    }
    tmp[3]=4;

    for(int i=0;i<4;i++)
    {
        printf("%d\n",x[i]);

    }
    free(x);
    return 0;
}
