#include <stdio.h>
#include <stdlib.h>
#include <cs50.h>

typedef struct node
{
    int no;
    struct node *next;
} node;

int main(void)
{
   node *list = NULL;
    for(int i = 0 ;i<3;i++)
    {
        node *x = malloc(sizeof(node));
         if(x==NULL)
            {
                 return 1;
            }
    x->no = get_int("No:");
    x->next = NULL;

    //  if list is empty
    if(list == NULL)
    {
        list = x;
    }
    // if list has no already
    else
    {
        for(node *ptr = list; ptr != NULL; ptr = ptr->next)
        {
            // if at end of list
            if(ptr->next == NULL)
            {
                ptr->next=x;
                break;
            }
        }
    }
    }
    for(node *ptr= list;ptr!=NULL;ptr=ptr->next)
    {
        printf("%i\n",ptr->no);
    }

    node *ptr=list;
    while(ptr != NULL)
    {
        node *next=ptr->next;
        free(ptr);
        ptr = next;

    }
    return 0;
}
