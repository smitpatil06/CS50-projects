people={
    "tesh":"12-3456-7789-0098",
    "mayu":"12-3456-7789-0099",
    "gunu":"12-3456-7789-0100",
}
name=input("names :")

if name in people:
    print(f"number={people[name]} ")
else:
    print("not found")
