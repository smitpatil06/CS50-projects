x=int(input("x:"))
y=int(input("y:"))

if x > y:
    print("x is greater",x)
elif y > x:
    print(f"x:{x} is greater")
else:
    print("x:",x," is greater")
