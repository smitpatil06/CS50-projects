import cowsay

name = input("whats my name:")
cowsay.cow(name)
