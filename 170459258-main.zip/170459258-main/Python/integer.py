'''n=input("enter a value ")

if n.isnumeric():
    print("is a number")
else:
    print("is not a number")
'''

try:
    a=int(input("enter a number"))

except ValueError:
    print("Not integer")
else:
    print("integer")

