
def main():
    i = 0
    while i<5:
        print("meow")
        i+=1

    for i in range(5):
        meow()
     
def meow():
    print("meow")


main()
