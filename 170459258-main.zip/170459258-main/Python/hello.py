ans = input("What's your name?")
print(f"hello , {ans}")

print("hello",ans)
