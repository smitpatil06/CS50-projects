'''import csv

with open("phonebook.csv","r") as file:
    book = csv.reader(file)
    for row in book:
        print(row[1])
'''
"""import csv

with open("phonebook.csv","r") as file:
    book = csv.DictReader(file)
    for r in book:  # r for row
        fav = r["name"]
        print(fav)
"""
'''import csv

with open("phonebook.csv","r") as file:
    read= csv.DictReader(file)
    scratch, c, python = 0, 0, 0
    for r in read:
       fav = r["language"]
       print(fav)
'''

import csv

with open("phonebook.csv","r") as file:
    read= csv.DictReader(file)
    counts={}
    for row in read:
        fav = row["language"]
        if fav in counts:
            counts[fav]+= 1
        else:
            counts[fav] = 1

    for fav in sorted(counts, key=counts.get, reverse = True):
        print(f"{fav}:{counts[fav]}")
