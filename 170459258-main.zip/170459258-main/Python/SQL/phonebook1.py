'''
import csv

file = open("phonebook.csv","a")

name=input("Name: ")
number=input("Number: ")

writer=csv.writer(file)
writer.writerow([name,number])

file.close()

'''

import csv

name = []
number = []
language = []
n = 5
for i in range(n):
    name.append(input("name:"))
    number.append(input("number:"))
    language.append(input("language:"))

with open("phonebook.csv", "a") as file:
    writer = csv.DictWriter(file, fieldnames=["name", "number", "language"])

    for i in range(n):
        writer.writerow({"name": name[i], "number": number[i], "language": language[i]})
