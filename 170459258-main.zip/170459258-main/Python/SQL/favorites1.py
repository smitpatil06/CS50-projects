from cs50 import SQL

file = SQL("sqlite:///fav.db")

fav = input("favorite: ")

rows = file.execute("SELECT COUNT(*) AS n FROM fav WHERE language = ?",fav)
row=rows[0]
print(row["n"])
