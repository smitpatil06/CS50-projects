'''from sys import argv

if len(argv)==2:
    print(f"hello, {argv[1]}")
else:
    print("hello, world")

'''

import sys
if len(sys.argv) == 2:
    print("Missing command-line")

else
print(f"hello ,{sys.argv[1]}")

