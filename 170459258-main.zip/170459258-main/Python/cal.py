x=int(input("enter a number"))
y=int(input("enter a number"))

print(x/y)

z=x/y
print(f"{z:.50f}")
