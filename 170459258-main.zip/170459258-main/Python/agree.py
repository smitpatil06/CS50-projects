s=input("Do you agree?")

if s == "Y" or s== "y":
    print("Agreed")
elif s == "N" or s== "n":
    print("Not Agreed")
